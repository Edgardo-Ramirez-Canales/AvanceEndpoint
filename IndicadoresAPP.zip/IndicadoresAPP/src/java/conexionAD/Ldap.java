package conexionAD;

import java.util.ArrayList;
import java.util.Hashtable;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import java.util.Arrays;


import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.naming.directory.Attribute;

public class Ldap
{
  private DirContext ctx;
  private  final String host;
  private final String domain;
  private final String subdominio;
  private String user;
  private String pass;
  private String errorLdap = "";
  private Object codeErrorLdap = "";
  private final String INITCTX = "com.sun.jndi.ldap.LdapCtxFactory";
  
  public Ldap()
  {
    this.ctx = null;
    this.host = "ldap://172.23.6.80:389/";
    this.domain = "gfficohsa";
    this.subdominio = ".hn";
  }
  
  public String getUser()
  {
    return this.user;
  }
  
  public String getPass()
  {
    return this.pass;
  }
  
  public String getErrorLdap()
  {
    return this.errorLdap;
  }
  
  public Object getCodeErrorLdap()
  {
    return this.codeErrorLdap;
  }
  
  public Boolean autenticar(String usuario, String paswword)
  {
    Boolean result = false;
    
    this.user = usuario;
    this.pass = paswword;
    
    Hashtable<String, String> env = new Hashtable();
    if ((this.pass.compareTo("") == 0) || (this.user.compareTo("") == 0)) {
      return null;
    }
    env.put("java.naming.factory.initial", this.INITCTX);
    env.put("java.naming.provider.url", this.host);
    env.put("java.naming.security.authentication", "simple");
    env.put("java.naming.security.principal", new String(this.domain + "\\" + this.user));
    env.put("java.naming.security.credentials", new String(this.pass));
    try
    {
      this.ctx = new InitialDirContext(env);
      result = true;
    }
    catch (NamingException e)
    {
      String mensaje = e.getMessage();
      Boolean falloCredenciales = Boolean.valueOf(mensaje.contains("error code 49"));
      if (falloCredenciales.booleanValue())
      {
        result = Boolean.valueOf(false);
      }
      else
      {
        this.errorLdap = e.getLocalizedMessage();
        this.codeErrorLdap = Integer.valueOf(e.hashCode());
        return Boolean.valueOf(false);
      }
    }
    if (!result.booleanValue())
    {
      this.errorLdap = "La identificaci0n/contraseña es invalida";
      this.codeErrorLdap = Long.valueOf(-1254L);
    }
    return result;
  }
  
      
 
  private static String toDC(String domainName)
  {
    StringBuilder buf = new StringBuilder();
    for (String token : domainName.split("\\.")) {
      if (token.length() != 0)
      {
        if (buf.length() > 0) {
          buf.append(",");
        }
        buf.append("DC=").append(token);
      }
    }
    return buf.toString();
  }
  
  private static String toOU(String unidad)
  {
    StringBuilder buf = new StringBuilder();
    for (String token : unidad.split("\\.")) {
      if (token.length() != 0)
      {
        if (buf.length() > 0) {
          buf.append(",");
        }
        buf.append("OU=").append(token);
      }
    }
    return buf.toString();
  }
  
  
  public static void main(String[] args) throws Exception {
    Ldap ldap = new Ldap();

    // Prueba de autenticación
     String usuario = "PR00163";
     String password = "Acar69f8kel1234567";
     Boolean isAuthenticated = ldap.autenticar(usuario, password);

        if (isAuthenticated) {
           System.out.println("Autenticado exitosamente");       
    }
  }
}  
  

   



package dao;


import model.Persona;
import java.util.ArrayList;
import java.util.List;

public class PersonaDAO {
     private static List<Persona> personas = new ArrayList<>();
     
     static {
        personas.add(new Persona(1L, "Juan", 30));
        personas.add(new Persona(2L, "Ana", 25));
        // ... puedes agregar más personas para simular
    }
     
     public List<Persona> obtenerTodos() {
        return personas;
    }

    public Persona obtenerPorId(Long id) {
        return personas.stream()
                       .filter(p -> p.getId().equals(id))
                       .findFirst()
                       .orElse(null);
    }
     
}


package controller;

import model.Persona;
import service.PersonaService;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import java.util.List;


@Path("persona")
public class PersonaController {
    private final PersonaService service = new PersonaService();

    @Context
    private UriInfo context;

   
    public PersonaController() {
    }

    
    @GET
     @Path("/hello")
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    public String getJson() {
        //TODO return proper representation object
        return "{\"message\":\"Hello Cracks\"}";
    }
   
    @GET
     @Path("/lista")
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    public List<Persona> obtenerTodas () {
        //TODO return proper representation object
        return service.obtenerTodos();
    }

    
      @GET
      @Path("/{id}")
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    public Persona obtenerPorId(@PathParam("id") Long id) {
        //TODO return proper representation object
        return service.obtenerPorId(id);
    }

    
  
}

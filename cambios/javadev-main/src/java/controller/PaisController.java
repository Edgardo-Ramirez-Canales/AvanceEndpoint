
package controller;

import model.Pais;
import dao.PaisDAO;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;


@Path("Pais")
public class PaisController {

     private PaisDAO paisDAO;

    
    public PaisController() {
        this.paisDAO = new PaisDAO();
    }

    
    @GET
     @Path("/pais")
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    public String getJson() {
        //TODO return proper representation object
        return "{\"message\":\"Hello Cracks PAIS\"}";
    }

    
    @GET
    @Path("/{recId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getPais(@PathParam("recId") String recId) {
        try {
            Pais pais = paisDAO.obtenerPaisPorRecId(recId);
            if (pais != null) {
                return Response.ok(pais).build();
            } else {
                return Response.status(Response.Status.NOT_FOUND).entity("Pais no encontrado, vuelve a buscar").build();
            }
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
        }
    }
}

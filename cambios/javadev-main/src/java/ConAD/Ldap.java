package ConAD;

import java.util.ArrayList;
import java.util.Hashtable;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import java.util.Arrays;


import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import javax.naming.directory.Attribute;

public class Ldap
{
  private DirContext ctx;
  private String host;
  private String domain;
  private String subdominio;
  private String user;
  private String pass;
  private String errorLdap = "";
  private Object codeErrorLdap = "";
  private String INITCTX = "com.sun.jndi.ldap.LdapCtxFactory";
  
  public Ldap()
  {
    this.ctx = null;
    this.host = "ldap://172.23.6.80:389/";
    this.domain = "gfficohsa";
    this.subdominio = ".hn";
  }
  
  public String getUser()
  {
    return this.user;
  }
  
  public String getPass()
  {
    return this.pass;
  }
  
  public String getErrorLdap()
  {
    return this.errorLdap;
  }
  
  public Object getCodeErrorLdap()
  {
    return this.codeErrorLdap;
  }
  
  public Boolean autenticar(String usuario, String paswword)
  {
    Boolean result = false;
    
    this.user = usuario;
    this.pass = paswword;
    
    Hashtable<String, String> env = new Hashtable();
    if ((this.pass.compareTo("") == 0) || (this.user.compareTo("") == 0)) {
      return null;
    }
    env.put("java.naming.factory.initial", this.INITCTX);
    env.put("java.naming.provider.url", this.host);
    env.put("java.naming.security.authentication", "simple");
    env.put("java.naming.security.principal", new String(this.domain + "\\" + this.user));
    env.put("java.naming.security.credentials", new String(this.pass));
    try
    {
      this.ctx = new InitialDirContext(env);
      result = true;
    }
    catch (NamingException e)
    {
      String mensaje = e.getMessage();
      Boolean falloCredenciales = Boolean.valueOf(mensaje.contains("error code 49"));
      if (falloCredenciales.booleanValue())
      {
        result = Boolean.valueOf(false);
      }
      else
      {
        this.errorLdap = e.getLocalizedMessage();
        this.codeErrorLdap = Integer.valueOf(e.hashCode());
        return Boolean.valueOf(false);
      }
    }
    if (!result.booleanValue())
    {
      this.errorLdap = "La identificaci0n/contrase&ntilde;a es invalida";
      this.codeErrorLdap = Long.valueOf(-1254L);
    }
    return result;
  }
  
      public SearchResult realizarBusqueda(String filtro, String clave, ArrayList<String> unidades) {
     SearchResult result = null;
     SearchControls controls = new SearchControls();
     controls.setSearchScope(2);
     String dominio = toDC(String.valueOf(this.domain) + this.subdominio);
     String unidad = "";
     String unidadOU = "";
     String base = "";
     Boolean encontrado = Boolean.valueOf(false);
     
     for (int i = 0; i < unidades.size(); i++) {
       unidad = unidades.get(i);
       unidadOU = toOU(unidad);
       base = String.valueOf(unidadOU) + "," + dominio;
       try {
         NamingEnumeration<SearchResult> renum = this.ctx.search(base, "(& (" + filtro + "=" + clave + "))", controls);
         if (renum.hasMoreElements()) {
           result = renum.next();
           encontrado = Boolean.valueOf(true);
           break;
         } 
         encontrado = Boolean.valueOf(false);
       }
       catch (NamingException e) {
         System.out.println( e);
         System.out.println( "callo en naming");
       } 
     } 
     if (!encontrado.booleanValue()) {
       result = null;
     }
     return result;
  }
  
public SearchResult obtenerGrupo(String usuario, ArrayList<String> unidades) {
    SearchResult result = null;
    String filter = "(&(objectClass=person)(userPrincipalName=" + usuario + "@" + this.domain + this.subdominio + "))";
    String[] attrs = { "memberOf" };
    SearchControls controls = new SearchControls();
    controls.setSearchScope(SearchControls.SUBTREE_SCOPE); // Reemplazo el 2 por SearchControls.SUBTREE_SCOPE para mejor legibilidad
    controls.setReturningAttributes(attrs);
    String dominio = toDC(this.domain + this.subdominio);
    Boolean encontrado = false;
    
    for (String unidad : unidades) { // Uso un foreach para iterar sobre las unidades
        String unidadOU = toOU(unidad);
        String base = unidadOU + "," + dominio;
        try {
            NamingEnumeration<SearchResult> renum = this.ctx.search(base, filter, controls);
            if (renum.hasMoreElements()) {
                result = renum.next();
                String memberOfAttrValue = result.getAttributes().get("memberOf").toString();
                System.out.println("Usuario encontrado en la unidad: " + unidad);
                encontrado = true;
                break; 
            } else {
                System.out.println("La unidad " + unidad + " existe, pero el usuario no se encuentra en ella.");
            }
        } catch (NamingException e) {
            System.out.println("Error al buscar en la unidad " + unidad + ". Es posible que esta unidad no exista.");
        }
    }
    
    if (!encontrado) {
        System.out.println("El usuario no se encontró en ninguna unidad proporcionada.");
        result = null;
    }
    return result;
}
 
  private static String toDC(String domainName)
  {
    StringBuilder buf = new StringBuilder();
    for (String token : domainName.split("\\.")) {
      if (token.length() != 0)
      {
        if (buf.length() > 0) {
          buf.append(",");
        }
        buf.append("DC=").append(token);
      }
    }
    return buf.toString();
  }
  
  private static String toOU(String unidad)
  {
    StringBuilder buf = new StringBuilder();
    for (String token : unidad.split("\\.")) {
      if (token.length() != 0)
      {
        if (buf.length() > 0) {
          buf.append(",");
        }
        buf.append("OU=").append(token);
      }
    }
    return buf.toString();
  }
  
  
  public static void main(String[] args) throws Exception {
    Ldap ldap = new Ldap();

    // Prueba de autenticación
     String usuario = "PR00163";
     String password = "Acar69f8kel12345";
     Boolean isAuthenticated = ldap.autenticar(usuario, password);

        if (isAuthenticated) {
          System.out.println("Autenticado exitosamente");

           // Convertir el string de unidades en una lista
           String unidadesStr = "Desarrollo.Sub Departamentos.Sistemas,Users.Banco Honduras,Desarrollo.Users.Banco Honduras";
           ArrayList<String> unidades = new ArrayList<>(Arrays.asList(unidadesStr.split(",")));

           // Prueba de obtenerGrupo
           SearchResult resultado = ldap.obtenerGrupo(usuario, unidades);

            // Opcional: imprimir el resultado para ver si el usuario fue encontrado y en qué grupo.
            if (resultado != null) {
           
                System.out.println("Usuario encontrado. Grupos a los que pertenece: " + resultado.getAttributes().get("memberOf"));  
            } else {
            System.out.println("Usuario no encontrado en las unidades proporcionadas.");
            } 
        }else {
        System.out.println("Error en la autenticación.");
       } 
    }
}  
  

   




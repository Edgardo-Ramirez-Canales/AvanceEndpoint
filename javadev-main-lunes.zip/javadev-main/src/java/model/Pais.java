
package model;


public class Pais {
    private String recId;
    private String createdBy;
    private java.util.Date createdDateTime;
    private String lastModBy;
    private java.util.Date lastModDateTime;
    private Boolean readOnly;
    private String pais;

    // Constructor, getters, setters, etc.

    public Pais() {
    }
    
     public String getRecId() {
        return recId;
    }

    public void setRecId(String recId) {
        this.recId = recId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public java.util.Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(java.util.Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public String getLastModBy() {
        return lastModBy;
    }

    public void setLastModBy(String lastModBy) {
        this.lastModBy = lastModBy;
    }

    public java.util.Date getLastModDateTime() {
        return lastModDateTime;
    }

    public void setLastModDateTime(java.util.Date lastModDateTime) {
        this.lastModDateTime = lastModDateTime;
    }

    public Boolean getReadOnly() {
        return readOnly;
    }

    public void setReadOnly(Boolean readOnly) {
        this.readOnly = readOnly;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    
}

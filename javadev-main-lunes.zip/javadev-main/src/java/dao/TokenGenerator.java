
package dao;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.JWTVerifier;

import java.util.Date;



public class TokenGenerator {
    
        public TokenGenerator(){}
    
    
        public String generateToken(String username, String[] roles) {
            try {
                Algorithm algorithm = Algorithm.HMAC256("secret"); // Utiliza una clave secreta más segura en producción
                
                long currentTimeMillis = System.currentTimeMillis();
                long expTimeMillis = currentTimeMillis + (60 * 60 * 1000); // Token válido por 1 hora
                return JWT.create()
                    .withSubject(username)
                    .withArrayClaim("roles", roles)
                    .withIssuedAt(new Date(currentTimeMillis))
                    .withExpiresAt(new Date(expTimeMillis))
                    .sign(algorithm);
            } catch (JWTCreationException exception) {
                //Invalid Signing configuration / Couldn't convert Claims.
                throw new RuntimeException("Error al crear el token JWT", exception);
            }
        }
        
        /*public boolean verifyToken(String token) {
            try {
                Algorithm algorithm = Algorithm.HMAC256("secret"); // La misma clave secreta usada para firmar el token
                JWTVerifier verifier = JWT.require(algorithm).build();
                DecodedJWT jwt = verifier.verify(token);

                 // Aquí puedes añadir más validaciones de claims si es necesario
                 // Por ejemplo: verificar si el token contiene los roles esperados

                 return true; // El token es válido
            } catch (JWTVerificationException exception) {
            // El token es inválido o la verificación falló
            return false;
            }
        }*/
        
    public DecodedJWT verifyToken(String token) {
        try {
             Algorithm algorithm = Algorithm.HMAC256("secret");
            JWTVerifier verifier = JWT.require(algorithm).build();
        return verifier.verify(token);
        } catch (JWTVerificationException exception) {
            return null;
        }
    }    
        
        
        
     
     
     
    
     public static void main(String[] args) {
        TokenGenerator generator = new TokenGenerator();

        String usuarioDePrueba = "edgardo";
        String[] rolesDePrueba = {"admin", "usuario"};
        String token = generator.generateToken(usuarioDePrueba, rolesDePrueba);
        // verificar el token 
        //TokenVerifier verifier = new TokenVerifier();
        //boolean esTokenValido = generator.verifyToken(token);
        

        System.out.println("Este Token fue generado: " + token);
       // System.out.println("Es el token valido?" + esTokenValido);
    }
}


package dao;

import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import java.lang.reflect.Method;
import java.util.List;
import javax.annotation.Priority;
import javax.ws.rs.Priorities;
import javax.ws.rs.ext.Provider;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ResourceInfo;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import java.util.Collections;


@Priority(Priorities.AUTHORIZATION)
public class AuthorizationFilter implements ContainerRequestFilter {
    
    private TokenGenerator tokenGenerator = new TokenGenerator();

    @Context
    private ResourceInfo resourceInfo;

    @Override
    public void filter(ContainerRequestContext requestContext) {
        Method method = resourceInfo.getResourceMethod();
        if (method.isAnnotationPresent(AuthorizationRequired.class)) {
            // Obtener los roles de la anotación
            String[] roles = method.getAnnotation(AuthorizationRequired.class).roles();

            // Obtener el token del encabezado
            String token = requestContext.getHeaderString(HttpHeaders.AUTHORIZATION);
            if (token == null || !token.startsWith("Bearer ")) {
                requestContext.abortWith(Response.status(Response.Status.UNAUTHORIZED).build());
                return;
            }

            token = token.substring(7); // Eliminar "Bearer "

            // Verificar el token y los roles
            if (!verifyTokenAndRoles(token, roles)) {
                requestContext.abortWith(Response.status(Response.Status.FORBIDDEN).build());
            }
        }
    }

    private boolean verifyTokenAndRoles(String token, String[] requiredRoles) {
        DecodedJWT decodedJWT = tokenGenerator.verifyToken(token);
            if (decodedJWT == null) {
                return false;
            }
            List<String> tokenRoles = getRolesFromToken(decodedJWT);
            for (String requiredRole : requiredRoles) {
                if (tokenRoles.contains(requiredRole)) {
                return true;
                }
            }
        return false;
    }

    private List<String> getRolesFromToken(DecodedJWT jwt) {
        Claim rolesClaim = jwt.getClaim("roles"); // Asume que los roles están en un claim llamado "roles"
        if (!rolesClaim.isNull()) {
            return rolesClaim.asList(String.class);
        }
        return Collections.emptyList();
    }

}



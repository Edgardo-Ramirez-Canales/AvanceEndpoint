
package controller;


import model.Estudiante;
import dao.EstudianteDAO;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;


@Path("estudiante")
public class EstudianteController {
    
    private EstudianteDAO estudianteDAO;
    
  
    public EstudianteController() {
        this.estudianteDAO = new EstudianteDAO();
    }
    
    @GET
     @Path("/estudiante")
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    public String getJson() {
        //TODO return proper representation object
        return "{\"message\":\"Hello Cracks Estudiante\"}";
    }
    
     @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getEstudiante(@PathParam("id") int id) {
        try {
            Estudiante estudiante = estudianteDAO.obtenerEstudiantePorId(id);
            if (estudiante != null) {
                return Response.ok(estudiante).build();
            } else {
                return Response.status(Response.Status.NOT_FOUND).entity("Estudiante no encontrado vuelve a buscar").build();
            }
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
        }
    }
  
}

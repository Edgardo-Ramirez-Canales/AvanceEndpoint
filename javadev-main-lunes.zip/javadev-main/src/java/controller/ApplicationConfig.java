
package controller;

import java.util.Set;


@javax.ws.rs.ApplicationPath("webresources")
public class ApplicationConfig extends javax.ws.rs.core.Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<>();
        addRestResourceClasses(resources);
        return resources;
    }

   
    private void addRestResourceClasses(Set<Class<?>> resources) {
        resources.add(controller.CorsFilter.class);
        resources.add(controller.EstudianteController.class);
        resources.add(controller.LoginController.class);
        resources.add(controller.PaisController.class);
        resources.add(controller.PersonaController.class);
    }
    
}

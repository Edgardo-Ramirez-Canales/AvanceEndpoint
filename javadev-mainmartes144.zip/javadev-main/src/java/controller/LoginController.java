
package controller;

import dao.LoginDAO;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.POST;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.json.JSONException;
import org.json.JSONObject;


@Path("login")
public class LoginController {

   
   private LoginDAO loginDAO;

    public LoginController() {
        this.loginDAO = new LoginDAO();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response autenticarUsuario(String credenciales) throws JSONException {
        try {
            JSONObject credencialesJson = new JSONObject(credenciales);
            String usuario = credencialesJson.getString("usuario");
            String password = credencialesJson.getString("password");

            String resultado = loginDAO.autenticar(usuario, password);

            if (resultado.startsWith("Error") || resultado.startsWith("Credenciales") || resultado.startsWith("Usuario no existe")) {
                return Response.status(Response.Status.UNAUTHORIZED).entity(new JSONObject().put("error", resultado).toString()).build();
            }

            return Response.ok(new JSONObject().put("token", resultado).toString()).build();

        } catch (JSONException e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(new JSONObject().put("error", e.getMessage()).toString()).build();
        }
    }
}

package dao;

import jakarta.annotation.Priority;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.ext.Provider;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ResourceInfo;
import java.lang.reflect.Method;
import javax.ws.rs.core.Context;
import static org.glassfish.hk2.utilities.reflection.Pretty.method;
import static org.glassfish.jersey.internal.util.Pretty.method;


@Provider
//@Priority(Priorities.AUTHORIZATION)
public class AuthorizationFilter implements ContainerRequestFilter {
    
    private static final Logger LOGGER = Logger.getLogger(AuthorizationFilter.class.getName());

    @Override
    public void filter(ContainerRequestContext requestContext) {
        String path = requestContext.getUriInfo().getPath();
        if (rutaProtegida(path)) {
            LOGGER.info("FILTRO EJECUTADA en ruta protegida");
            // Aquí agregas la lógica de autorización
        } else {
            LOGGER.info("Filtro no aplicado, ruta no protegida");
        }
    }
    
   private boolean rutaProtegida(String path) {
        // Define las rutas que requieren autorización
        // Ruta de login es pública solo para métodos POST
        if (path.startsWith("login") ) {
            return false;
        }
        // Ruta de Pais/pais es privada
        return path.startsWith("Pais/pais");
    }

   
 
    
    
   // public void filter(ContainerRequestContext requestContext) {
        //String token = requestContext.getHeaderString(HttpHeaders.AUTHORIZATION);
       // LOGGER.info("FILTRO EJECUTADA");
        /*if (token != null && token.startsWith("Bearer ")) {
            LOGGER.log(Level.INFO, "Token encontrado: {0}", token);
        } else {
            LOGGER.info("NO SE ENCONTRO TOKEN");
            System.out.println("NO HAY TOKEN");
        }
         System.out.println("AQUI TERMINA LA FUNCION");
        */

        // No abortar la solicitud, permitirla continuar
        // requestContext.abortWith(Response.status(Response.Status.UNAUTHORIZED).build());
   // } 
   
}
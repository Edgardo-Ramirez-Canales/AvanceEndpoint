
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Estudiante;

public class EstudianteDAO {

    private ConexionDB conexionDB;

    public EstudianteDAO() {
        this.conexionDB = new ConexionDB();
    }

    public Estudiante obtenerEstudiantePorId(int id) throws SQLException { // Agregar throws SQLException
        Estudiante estudiante = null;
        Connection conn = null;

        try {
            conn = conexionDB.getConnection(); // obtenemos la conexión

            String query = "SELECT id,nombre,edad,grado FROM Estudiantes WHERE id = ?"; // Corregir la consulta
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                estudiante = new Estudiante();
                estudiante.setId(id);
                estudiante.setNombre(rs.getString("nombre"));
                estudiante.setEdad(rs.getInt("edad"));
                estudiante.setGrado(rs.getString("grado"));
            }

            rs.close();
            stmt.close();
        } catch (SQLException e) {
            throw new SQLException("Error al obtener el estudiante con ID: " + id, e);
        } finally {
            if (conn != null) {
                try {
                    conn.close(); // cerramos la conexión aquí
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return estudiante;
    }
}
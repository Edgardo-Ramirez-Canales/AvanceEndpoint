
package dao;
import ConAD.Ldap;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

//import org.json.JSONArray;
//import javax.json.Json;


public class LoginDAO {
    
    public LoginDAO(){
    
    }
    
    public Boolean autenticar(String user, String pass) {
    try {
        Ldap ldap = new Ldap();
        boolean valido = ldap.autenticar(user, pass);

        if (valido) {
            System.out.println("Autenticado exitosamente LOGIN");
        } else {
            System.out.println("Error en la autenticación LOGIN: Credenciales inválidas.");
        }
        return valido;
        
    } catch (Exception ex) {
        System.out.println("Error en la autenticación LOGIN: " + ex.getMessage());
        return false; // O manejar según el tipo de excepción si es necesario
    }
    }

    
    public boolean existeUsuario(String usuario) {
        IVTConexionDB dbConnection = new IVTConexionDB();
        Connection con = dbConnection.getConnection();
        boolean existe = false;

        if (con != null) {
            try {
                Statement stmt = con.createStatement();
                String query = "SELECT * FROM EMPLOYEE WHERE Emp_LoginId = '" + usuario + "'";
                ResultSet rs = stmt.executeQuery(query);

                if (rs.next()) {
                    existe = true; // El usuario existe si se encuentra al menos un registro
                    System.out.println("El usuari existe en ivanti");
                }else{
                    existe = false; // El usuario existe si se encuentra al menos un registro
                    System.out.println("El usuari NO existe en ivanti");
                }
            } catch (SQLException e) {
                System.out.println("Error en la consulta SQL: " + e.getMessage());
            } finally {
                try {
                    con.close();
                } catch (SQLException e) {
                    System.out.println("Error al cerrar la conexión: " + e.getMessage());
                }
            }
        }
        return existe;
    } 
    
    
     public String[] obtenerRolesUsuario(String usuario) {
        IVTConexionDB dbConnection = new IVTConexionDB();
        Connection con = dbConnection.getConnection();
        List<String> roles = new ArrayList<>();

        if (con != null) {
            String query = "SELECT r.roleID FROM Frs_CompositeContract_Identity u " +
                           "JOIN Frs_def_role_assignment t ON u.RecId = t.SourceID " +
                           "JOIN Frs_def_role r ON t.targetID = r.RecId " +
                           "WHERE u.LoginID = ?";
            try (PreparedStatement pstmt = con.prepareStatement(query)) {
                pstmt.setString(1, usuario);
                ResultSet rs = pstmt.executeQuery();

                while (rs.next()) {
                    roles.add(rs.getString("roleID"));
                }
            } catch (SQLException e) {
                System.out.println("Error en la consulta SQL: " + e.getMessage());
            } finally {
                try {
                    con.close();
                } catch (SQLException e) {
                    System.out.println("Error al cerrar la conexión: " + e.getMessage());
                }
            }
        }
        return roles.toArray(String[]::new);
    }

    
    
    /*public JSONObject obtenerRolesUsuario(String usuario) {
        IVTConexionDB dbConnection = new IVTConexionDB();
        Connection con = dbConnection.getConnection();
        JSONObject rolesJson = new JSONObject();
        JSONArray rolesArray = new JSONArray();

        if (con != null) {
            String query = "SELECT u.LoginID, r.roleID FROM Frs_CompositeContract_Identity u " +
                           "JOIN Frs_def_role_assignment t ON u.RecId = t.SourceID " +
                           "JOIN Frs_def_role r ON t.targetID = r.RecId " +
                           "WHERE u.LoginID = ?";
            try (PreparedStatement pstmt = con.prepareStatement(query)) {
                pstmt.setString(1, usuario);
                ResultSet rs = pstmt.executeQuery();

                while (rs.next()) {
                    JSONObject role = new JSONObject();
                    role.put("LoginID", rs.getString("LoginID"));
                    role.put("RoleID", rs.getString("roleID"));
                    rolesArray.put(role);
                }
                rolesJson.put("Roles", rolesArray);
                
            } catch (SQLException e) {
                System.out.println("Error en la consulta SQL: " + e.getMessage());
            } finally {
                try {
                    con.close();
                } catch (SQLException e) {
                    System.out.println("Error al cerrar la conexión: " + e.getMessage());
                }
            }
        }
        return rolesJson;
    }*/
    
    public static void main (String[] arg){
        LoginDAO loginDAO =  new LoginDAO();
        String usuario = "PR00163";
        String password = "Acar69f8kel1234567";    
    
        loginDAO.autenticar(usuario,password);
        loginDAO.existeUsuario(usuario);
        String[] roles = loginDAO.obtenerRolesUsuario(usuario);
        
        System.out.println("Roles del usuario" + usuario + ":");
        for (String rol: roles){
            System.out.println(rol);
        }
    }
    
}

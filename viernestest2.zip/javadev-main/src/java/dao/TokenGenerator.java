
package dao;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;

import java.util.Date;



public class TokenGenerator {
    
    public TokenGenerator(){}
    
    
     public String generateToken(String username, String[] roles) {
        try {
            Algorithm algorithm = Algorithm.HMAC256("secret"); // Utiliza una clave secreta más segura en producción

            long currentTimeMillis = System.currentTimeMillis();
            long expTimeMillis = currentTimeMillis + (60 * 60 * 1000); // Token válido por 1 hora
            return JWT.create()
                    .withSubject(username)
                    .withArrayClaim("roles", roles)
                    .withIssuedAt(new Date(currentTimeMillis))
                    .withExpiresAt(new Date(expTimeMillis))
                    .sign(algorithm);
        } catch (JWTCreationException exception) {
            //Invalid Signing configuration / Couldn't convert Claims.
            throw new RuntimeException("Error al crear el token JWT", exception);
        }
    }
    
     public static void main(String[] args) {
        TokenGenerator generator = new TokenGenerator();

        String usuarioDePrueba = "edgardo";
        String[] rolesDePrueba = {"admin", "usuario"};

        String token = generator.generateToken(usuarioDePrueba, rolesDePrueba);

        System.out.println("Token generado: " + token);
    }
}

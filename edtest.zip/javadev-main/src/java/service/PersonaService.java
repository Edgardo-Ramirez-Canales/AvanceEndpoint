
package service;

import dao.PersonaDAO;
import model.Persona;
import java.util.List;

public class PersonaService {
    
    private final PersonaDAO dao = new PersonaDAO();

    public List<Persona> obtenerTodos() {
        return dao.obtenerTodos();
    }

    public Persona obtenerPorId(Long id) {
        return dao.obtenerPorId(id);
    }
    
    
}

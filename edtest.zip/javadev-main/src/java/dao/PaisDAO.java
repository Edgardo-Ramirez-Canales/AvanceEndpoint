
package dao;

import model.Pais;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class PaisDAO {
    
    private IVTConexionDB ivtConexionDB;
    
    public PaisDAO() {
        this.ivtConexionDB = new IVTConexionDB();
    }
    
    public Pais obtenerPaisPorRecId(String recId) throws SQLException {
    Pais pais = null;
    Connection conn = null;

    try {
        conn = ivtConexionDB.getConnection(); // obtenemos la conexión

        String query = "SELECT RecId, CreatedBy, CreatedDateTime, LastModBy, LastModDateTime, ReadOnly, Pais FROM AA_paises WHERE RecId = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, recId);  // Dado que RecId es VARCHAR, usamos setString
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            pais = new Pais();
            pais.setRecId(rs.getString("RecId"));
            pais.setCreatedBy(rs.getString("CreatedBy"));
            pais.setCreatedDateTime(rs.getTimestamp("CreatedDateTime"));
            pais.setLastModBy(rs.getString("LastModBy"));
            pais.setLastModDateTime(rs.getTimestamp("LastModDateTime"));
            pais.setReadOnly(rs.getBoolean("ReadOnly"));
            pais.setPais(rs.getString("Pais"));
        }

        rs.close();
        stmt.close();
    } catch (SQLException e) {
        throw new SQLException("Error al obtener el país con RecId: " + recId, e);
    } finally {
        if (conn != null) {
            try {
                conn.close(); // cerramos la conexión aquí
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    return pais;
}
    
}
